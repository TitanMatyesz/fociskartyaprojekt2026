let currentUser = null;

const authSection = document.getElementById("authSection");
const userSection = document.getElementById("userSection");
const userPlayers = document.getElementById("userPlayers");
const publicPlayers = document.getElementById("publicPlayers");
const message = document.getElementById("message");

function showMessage(text, isError = false) {
    message.textContent = text;
    message.style.color = isError ? "crimson" : "green";
}

// kártya létrehozása
function createPlayerCard(player, editable = false) {
    const col = document.createElement("div");
    col.className = "col-12 col-sm-6 col-lg-4";

    const card = document.createElement("div");
    card.className = "player-card";

    if (player.image) {
        const img = document.createElement("img");
        img.src = player.image;
        img.alt = player.name;
        img.onerror = () => {
            img.style.display = "none";
        };
        card.appendChild(img);
    }

    const title = document.createElement("h4");
    title.textContent = player.name;
    card.appendChild(title);

    const details = [
        ["Klub", player.club],
        ["Nemzetiség", player.nationality],
        ["Poszt", player.position]
    ];

    details.forEach(([label, value]) => {
        const p = document.createElement("p");
        p.textContent = `${label}: ${value}`;
        card.appendChild(p);
    });

    if (editable && currentUser) {
        const actions = document.createElement("div");
        actions.className = "card-actions mt-2";

        const editBtn = document.createElement("button");
        editBtn.type = "button";
        editBtn.className = "btn btn-sm btn-warning";
        editBtn.textContent = "Szerkesztés";

        editBtn.onclick = () => {
            card.innerHTML = "";

            const nameInput = document.createElement("input");
            nameInput.className = "form-control form-control-sm mb-2";
            nameInput.value = player.name;
            nameInput.placeholder = "Név";

            const clubInput = document.createElement("input");
            clubInput.className = "form-control form-control-sm mb-2";
            clubInput.value = player.club;
            clubInput.placeholder = "Klub";

            const natInput = document.createElement("input");
            natInput.className = "form-control form-control-sm mb-2";
            natInput.value = player.nationality;
            natInput.placeholder = "Nemzetiség";

            const posInput = document.createElement("input");
            posInput.className = "form-control form-control-sm mb-2";
            posInput.value = player.position;
            posInput.placeholder = "Poszt";

            const imgInput = document.createElement("input");
            imgInput.className = "form-control form-control-sm mb-2";
            imgInput.value = player.image || "";
            imgInput.placeholder = "Kép URL-je";

            card.append(nameInput, clubInput, natInput, posInput, imgInput);

            const saveBtn = document.createElement("button");
            saveBtn.type = "button";
            saveBtn.className = "btn btn-sm btn-success me-2";
            saveBtn.textContent = "Mentés";

            saveBtn.onclick = () => {
                fetch(`/api/players/${currentUser.id}/${player.id}`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        name: nameInput.value.trim(),
                        club: clubInput.value.trim(),
                        nationality: natInput.value.trim(),
                        position: posInput.value.trim(),
                        image: imgInput.value.trim()
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.id) {
                        showMessage("Kártya frissítve!");
                        loadUserPlayers();
                    } else {
                        showMessage(data.message || "Nem sikerült a módosítás!", true);
                    }
                })
                .catch(() => showMessage("Hiba történt a módosítás során!", true));
            };

            const cancelBtn = document.createElement("button");
            cancelBtn.type = "button";
            cancelBtn.className = "btn btn-sm btn-secondary";
            cancelBtn.textContent = "Mégse";
            cancelBtn.onclick = loadUserPlayers;

            card.append(saveBtn, cancelBtn);
        };

        const deleteBtn = document.createElement("button");
        deleteBtn.type = "button";
        deleteBtn.className = "btn btn-sm btn-danger ms-2";
        deleteBtn.textContent = "Törlés";

        deleteBtn.onclick = () => {
            if (!confirm("Biztosan törlöd ezt a focistakártyát?")) return;

            fetch(`/api/players/${currentUser.id}/${player.id}`, {
                method: "DELETE"
            })
            .then(res => res.json())
            .then(data => {
                if (data.message) {
                    showMessage("Kártya törölve!");
                    loadUserPlayers();
                } else {
                    showMessage("Nem sikerült a törlés!", true);
                }
            })
            .catch(() => showMessage("Hiba történt a törlés során!", true));
        };

        actions.append(editBtn, deleteBtn);
        card.appendChild(actions);
    }

    col.appendChild(card);
    return col;
}

// 9 focista
function loadPublicPlayers() {
    fetch("/api/players/public")
        .then(res => res.json())
        .then(data => {
            publicPlayers.innerHTML = "";
            data.forEach(player => {
                publicPlayers.appendChild(createPlayerCard(player, false));
            });
        })
        .catch(() => showMessage("Nem sikerült betölteni a híres focistákat!", true));
}

// saját kártyák
function loadUserPlayers() {
    if (!currentUser) return;

    fetch(`/api/players/user/${currentUser.id}`)
        .then(res => res.json())
        .then(data => {
            userPlayers.innerHTML = "";
            if (data.length === 0) {
                userPlayers.innerHTML = "<p class='text-muted'>Még nincs saját focistakártyád.</p>";
                return;
            }
            data.forEach(player => {
                userPlayers.appendChild(createPlayerCard(player, true));
            });
        })
        .catch(() => showMessage("Nem sikerült betölteni a saját kártyákat!", true));
}

// regisztráció
document.getElementById("registerForm").onsubmit = (e) => {
    e.preventDefault();

    fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            username: document.getElementById("regUsername").value.trim(),
            email: document.getElementById("regEmail").value.trim(),
            password: document.getElementById("regPassword").value
        })
    })
    .then(res => res.json().then(data => ({ ok: res.ok, data })))
    .then(({ ok, data }) => {
        if (ok) {
            showMessage("Sikeres regisztráció! Most már bejelentkezhetsz.");
            e.target.reset();
        } else {
            showMessage(data.message || "Sikertelen regisztráció!", true);
        }
    })
    .catch(() => showMessage("Hiba történt a regisztráció során!", true));
};

// bejelentkezés
document.getElementById("loginForm").onsubmit = (e) => {
    e.preventDefault();

    fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            email: document.getElementById("loginEmail").value.trim(),
            password: document.getElementById("loginPassword").value
        })
    })
    .then(res => res.json().then(data => ({ ok: res.ok, data })))
    .then(({ ok, data }) => {
        if (ok && data.id) {
            currentUser = data;
            authSection.hidden = true;
            userSection.hidden = false;
            document.getElementById("welcome").textContent = `Szia, ${data.username}!`;
            e.target.reset();
            showMessage("");
            loadUserPlayers();
        } else {
            showMessage(data.message || "Hibás e-mail cím vagy jelszó!", true);
        }
    })
    .catch(() => showMessage("Hiba történt a bejelentkezés során!", true));
};

// új focistakártya mentése
document.getElementById("playerForm").onsubmit = (e) => {
    e.preventDefault();
    if (!currentUser) return;

    fetch("/api/players", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            name: document.getElementById("playerName").value.trim(),
            club: document.getElementById("playerClub").value.trim(),
            nationality: document.getElementById("playerNationality").value.trim(),
            position: document.getElementById("playerPosition").value.trim(),
            image: document.getElementById("playerImage").value.trim(),
            userId: currentUser.id
        })
    })
    .then(res => res.json().then(data => ({ ok: res.ok, data })))
    .then(({ ok, data }) => {
        if (ok && data.id) {
            e.target.reset();
            showMessage("Új focistakártya elmentve!");
            loadUserPlayers();
        } else {
            showMessage(data.message || "Nem sikerült a mentés!", true);
        }
    })
    .catch(() => showMessage("Hiba történt a mentés során!", true));
};

// kijelentkezés
document.getElementById("logoutButton").onclick = () => {
    currentUser = null;
    userPlayers.innerHTML = "";
    userSection.hidden = true;
    authSection.hidden = false;
    showMessage("");
    document.querySelectorAll("form").forEach(form => form.reset());
};

loadPublicPlayers();