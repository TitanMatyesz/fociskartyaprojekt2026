import express from "express";
import Database from "better-sqlite3";
import bcrypt from "bcrypt";

const app = express();
const PORT = 3300;

app.use(express.json());
app.use(express.static("public"));

//adatbázisok
const usersDb = new Database("./data/users.db");
const playersDb = new Database("./data/players.db");

// táblák készítése ha még nincs
usersDb.prepare(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )
`).run();

playersDb.prepare(`
    CREATE TABLE IF NOT EXISTS players (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        club TEXT NOT NULL,
        nationality TEXT NOT NULL,
        position TEXT NOT NULL,
        image TEXT DEFAULT '',
        isPublic INTEGER NOT NULL DEFAULT 0,
        userId INTEGER NOT NULL DEFAULT 0
    )
`).run();

// 9 híres focista betöltése ha a tábla üres
const famousPlayers = [
    {
        name: "Lionel Messi",
        club: "Inter Miami",
        nationality: "Argentína",
        position: "Támadó",
        image: "https://upload.wikimedia.org/wikipedia/commons/b/b4/Lionel-Messi-Argentina-2022-FIFA-World-Cup_%28cropped%29.jpg"
    },
    {
        name: "Cristiano Ronaldo",
        club: "Al-Nassr",
        nationality: "Portugália",
        position: "Csatár",
        image: "https://upload.wikimedia.org/wikipedia/commons/d/d7/Cristiano_Ronaldo_playing_for_Al_Nassr_FC_against_Persepolis%2C_September_2023_%28cropped%29.jpg"
    },
    {
        name: "Kylian Mbappé",
        club: "Real Madrid",
        nationality: "Franciaország",
        position: "Támadó",
        image: "https://upload.wikimedia.org/wikipedia/commons/5/57/2019-07-17_SG_Dynamo_Dresden_vs._Paris_Saint-Germain_by_Sandro_Halank%E2%80%93129_%28cropped%29.jpg"
    },
    {
        name: "Erling Haaland",
        club: "Manchester City",
        nationality: "Norvégia",
        position: "Csatár",
        image: "https://thumb.wikimedia.org/wikipedia/commons/thumb/4/43/Erling_Haaland_Morocco_v_Norway_7_June_2026-51.jpg/250px-Erling_Haaland_Morocco_v_Norway_7_June_2026-51.jpg?utm_source=hu.wikipedia.org&utm_campaign=parser&utm_content=thumbnail"
    },
    {
        name: "Kevin De Bruyne",
        club: "Manchester City",
        nationality: "Belgium",
        position: "Középpályás",
        image: "https://thumb.wikimedia.org/wikipedia/commons/thumb/4/40/Kevin_De_Bruyne_USMNT_v_Belgium_Mar_28_2026-64_%28cropped%29.jpg/250px-Kevin_De_Bruyne_USMNT_v_Belgium_Mar_28_2026-64_%28cropped%29.jpg?utm_source=hu.wikipedia.org&utm_campaign=parser&utm_content=thumbnail"
    },
    {
        name: "Jude Bellingham",
        club: "Real Madrid",
        nationality: "Anglia",
        position: "Középpályás",
        image: "https://thumb.wikimedia.org/wikipedia/commons/thumb/2/23/Jude_Bellingham_England_v_Ghana_23_June_2026-061_%28cropped%29.jpg/250px-Jude_Bellingham_England_v_Ghana_23_June_2026-061_%28cropped%29.jpg?utm_source=hu.wikipedia.org&utm_campaign=parser&utm_content=thumbnail"
    },
    {
        name: "Luka Modrić",
        club: "Real Madrid",
        nationality: "Horvátország",
        position: "Középpályás",
        image: "https://thumb.wikimedia.org/wikipedia/commons/thumb/1/12/Luka_Modric_Croatia_v_Portugal_2_July_2026-025.jpg/250px-Luka_Modric_Croatia_v_Portugal_2_July_2026-025.jpg?utm_source=hu.wikipedia.org&utm_campaign=parser&utm_content=thumbnail"
    },
    {
        name: "Virgil van Dijk",
        club: "Liverpool",
        nationality: "Hollandia",
        position: "Védő",
        image: "https://thumb.wikimedia.org/wikipedia/commons/thumb/3/3d/20160604_AUT_NED_8876.jpg/250px-20160604_AUT_NED_8876.jpg?utm_source=hu.wikipedia.org&utm_campaign=parser&utm_content=thumbnail"
    },
    {
        name: "Szoboszlai Dominik",
        club: "Liverpool",
        nationality: "Magyarország",
        position: "Középpályás",
        image: "https://thumb.wikimedia.org/wikipedia/commons/thumb/6/6d/Dominik_Szoboszlai_06042025_%281%29.jpg/250px-Dominik_Szoboszlai_06042025_%281%29.jpg?utm_source=hu.wikipedia.org&utm_campaign=parser&utm_content=thumbnail"
    }
];

const { count } = playersDb.prepare("SELECT COUNT(*) AS count FROM players").get();

if (count === 0) {
    const insertFamous = playersDb.prepare(`
        INSERT INTO players (name, club, nationality, position, image, isPublic, userId)
        VALUES (?, ?, ?, ?, ?, 1, 0)
    `);

    famousPlayers.forEach(p => {
        insertFamous.run(p.name, p.club, p.nationality, p.position, p.image);
    });
}

// regisztráció
app.post("/api/register", (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ message: "Minden mező kitöltése kötelező!" });
    }

    const existing = usersDb.prepare("SELECT id FROM users WHERE email = ?").get(email);
    if (existing) {
        return res.status(400).json({ message: "Ez az e-mail cím már foglalt!" });
    }

    const hashedPassword = bcrypt.hashSync(password, 10);
    const saved = usersDb
        .prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)")
        .run(username, email, hashedPassword);

    const user = usersDb
        .prepare("SELECT id, username, email FROM users WHERE id = ?")
        .get(saved.lastInsertRowid);

    res.status(201).json(user);
});

// bejelentkezés
app.post("/api/login", (req, res) => {
    const { email, password } = req.body;

    const user = usersDb.prepare("SELECT * FROM users WHERE email = ?").get(email);
    if (!user || !bcrypt.compareSync(password, user.password)) {
        return res.status(401).json({ message: "Hibás e-mail cím vagy jelszó!" });
    }

    res.status(200).json({
        id: user.id,
        username: user.username,
        email: user.email
    });
});

// publikus 9 focista kártyája
app.get("/api/players/public", (req, res) => {
    const list = playersDb
        .prepare("SELECT * FROM players WHERE isPublic = 1 AND userId = 0 ORDER BY id ASC")
        .all();
    res.json(list);
});

// saját kártyák
app.get("/api/players/user/:userId", (req, res) => {
    const userId = Number(req.params.userId);
    const list = playersDb
        .prepare("SELECT * FROM players WHERE userId = ? ORDER BY id DESC")
        .all(userId);
    res.json(list);
});

// új focistakártya hozzáadása
app.post("/api/players", (req, res) => {
    const { name, club, nationality, position, image, userId } = req.body;

    if (!name || !club || !nationality || !position || !userId) {
        return res.status(400).json({ message: "Hiányzó adatok!" });
    }

    const saved = playersDb
        .prepare(`
            INSERT INTO players (name, club, nationality, position, image, isPublic, userId)
            VALUES (?, ?, ?, ?, ?, 0, ?)
        `)
        .run(name, club, nationality, position, image || "", Number(userId));

    const created = playersDb
        .prepare("SELECT * FROM players WHERE id = ?")
        .get(saved.lastInsertRowid);

    res.status(201).json(created);
});

// saját focistakártya módosítása
app.put("/api/players/:userId/:id", (req, res) => {
    const userId = Number(req.params.userId);
    const id = Number(req.params.id);
    const { name, club, nationality, position, image } = req.body;

    if (!name || !club || !nationality || !position) {
        return res.status(400).json({ message: "Hiányzó adatok!" });
    }

    const existing = playersDb
        .prepare("SELECT * FROM players WHERE id = ? AND userId = ?")
        .get(id, userId);

    if (!existing) {
        return res.status(404).json({ message: "A kártya nem található vagy nem a tied!" });
    }

    playersDb
        .prepare(`
            UPDATE players
            SET name = ?, club = ?, nationality = ?, position = ?, image = ?
            WHERE id = ? AND userId = ?
        `)
        .run(name, club, nationality, position, image || "", id, userId);

    const updated = playersDb
        .prepare("SELECT * FROM players WHERE id = ? AND userId = ?")
        .get(id, userId);

    res.status(200).json(updated);
});

// saját focistakártya törlése 
app.delete("/api/players/:userId/:id", (req, res) => {
    const userId = Number(req.params.userId);
    const id = Number(req.params.id);

    const existing = playersDb
        .prepare("SELECT * FROM players WHERE id = ? AND userId = ?")
        .get(id, userId);

    if (!existing) {
        return res.status(404).json({ message: "A kártya nem található vagy nem a tied!" });
    }

    playersDb
        .prepare("DELETE FROM players WHERE id = ? AND userId = ?")
        .run(id, userId);

    res.status(200).json({ message: "Kártya törölve!" });
});

app.listen(PORT, () => {
    console.log(`Szerver fut: http://localhost:${PORT}`);
});